/*
 * multirotor0_data.cpp
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "multirotor0".
 *
 * Model version              : 14.7
 * Simulink Coder version : 9.9 (R2023a) 19-Nov-2022
 * C++ source code generated on : Wed Aug 23 12:32:04 2023
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: 32-bit Generic
 * Code generation objective: Debugging
 * Validation result: Not run
 */

#include "multirotor0.h"

/* Constant parameters (default storage) */
const ConstP_multirotor0_T multirotor0_ConstP{
  /* Expression: MotorMatrix_real
   * Referenced by: '<S3>/Constant'
   */
  { 45.0, 135.0, 225.0, 315.0, 0.17, 0.17, 0.17, 0.17, -0.028, -0.028, -0.028,
    -0.028, -1.0, 1.0, -1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 0.01, 0.01, 0.01, 0.01,
    9.6820000000000012E-5, 9.6820000000000012E-5, 9.6820000000000012E-5,
    9.6820000000000012E-5, 1.0872000000000001E-7, 1.0872000000000001E-7,
    1.0872000000000001E-7, 1.0872000000000001E-7, 1.4504E-6, 1.4504E-6,
    1.4504E-6, 1.4504E-6, 1.6312E-9, 1.6312E-9, 1.6312E-9, 1.6312E-9, 0.0, 0.0,
    0.0, 0.0, 6000.0, 6000.0, 6000.0, 6000.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.2032, 0.2032, 0.2032, 0.2032, 0.011, 0.011, 0.011,
    0.011 },

  /* Expression: J_real
   * Referenced by: '<S3>/Constant3'
   */
  { 0.00396, 0.0, 0.0, 0.0, 0.003845, 0.0, 0.0, 0.0, 0.00735 }
};
