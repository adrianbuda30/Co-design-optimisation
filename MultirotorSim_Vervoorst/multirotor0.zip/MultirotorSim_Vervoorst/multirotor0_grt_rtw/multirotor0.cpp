/*
 * multirotor0.cpp
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "multirotor0".
 *
 * Model version              : 14.7
 * Simulink Coder version : 9.9 (R2023a) 19-Nov-2022
 * C++ source code generated on : Wed Aug 23 12:32:04 2023
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: 32-bit Generic
 * Code generation objective: Debugging
 * Validation result: Not run
 */

#include "multirotor0.h"
#include "rtwtypes.h"
#include <cmath>
#include "multirotor0_private.h"
#include <cstring>
#include "rt_defines.h"

extern "C"
{

#include "rt_nonfinite.h"

}

/*
 * This function updates continuous states using the ODE3 fixed-step
 * solver algorithm
 */
void multirotor0::rt_ertODEUpdateContinuousStates(RTWSolverInfo *si )
{
  /* Solver Matrices */
  static const real_T rt_ODE3_A[3]{
    1.0/2.0, 3.0/4.0, 1.0
  };

  static const real_T rt_ODE3_B[3][3]{
    { 1.0/2.0, 0.0, 0.0 },

    { 0.0, 3.0/4.0, 0.0 },

    { 2.0/9.0, 1.0/3.0, 4.0/9.0 }
  };

  time_T t { rtsiGetT(si) };

  time_T tnew { rtsiGetSolverStopTime(si) };

  time_T h { rtsiGetStepSize(si) };

  real_T *x { rtsiGetContStates(si) };

  ODE3_IntgData *id { static_cast<ODE3_IntgData *>(rtsiGetSolverData(si)) };

  real_T *y { id->y };

  real_T *f0 { id->f[0] };

  real_T *f1 { id->f[1] };

  real_T *f2 { id->f[2] };

  real_T hB[3];
  int_T i;
  int_T nXc { 21 };

  rtsiSetSimTimeStep(si,MINOR_TIME_STEP);

  /* Save the state values at time t in y, we'll use x as ynew. */
  (void) std::memcpy(y, x,
                     static_cast<uint_T>(nXc)*sizeof(real_T));

  /* Assumes that rtsiSetT and ModelOutputs are up-to-date */
  /* f0 = f(t,y) */
  rtsiSetdX(si, f0);
  multirotor0_derivatives();

  /* f(:,2) = feval(odefile, t + hA(1), y + f*hB(:,1), args(:)(*)); */
  hB[0] = h * rt_ODE3_B[0][0];
  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0]);
  }

  rtsiSetT(si, t + h*rt_ODE3_A[0]);
  rtsiSetdX(si, f1);
  this->step0();
  multirotor0_derivatives();

  /* f(:,3) = feval(odefile, t + hA(2), y + f*hB(:,2), args(:)(*)); */
  for (i = 0; i <= 1; i++) {
    hB[i] = h * rt_ODE3_B[1][i];
  }

  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0] + f1[i]*hB[1]);
  }

  rtsiSetT(si, t + h*rt_ODE3_A[1]);
  rtsiSetdX(si, f2);
  this->step0();
  multirotor0_derivatives();

  /* tnew = t + hA(3);
     ynew = y + f*hB(:,3); */
  for (i = 0; i <= 2; i++) {
    hB[i] = h * rt_ODE3_B[2][i];
  }

  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0] + f1[i]*hB[1] + f2[i]*hB[2]);
  }

  rtsiSetT(si, tnew);
  rtsiSetSimTimeStep(si,MAJOR_TIME_STEP);
}

real_T rt_atan2d_snf(real_T u0, real_T u1)
{
  real_T y;
  if (std::isnan(u0) || std::isnan(u1)) {
    y = (rtNaN);
  } else if (std::isinf(u0) && std::isinf(u1)) {
    int32_T tmp;
    int32_T tmp_0;
    if (u0 > 0.0) {
      tmp = 1;
    } else {
      tmp = -1;
    }

    if (u1 > 0.0) {
      tmp_0 = 1;
    } else {
      tmp_0 = -1;
    }

    y = std::atan2(static_cast<real_T>(tmp), static_cast<real_T>(tmp_0));
  } else if (u1 == 0.0) {
    if (u0 > 0.0) {
      y = RT_PI / 2.0;
    } else if (u0 < 0.0) {
      y = -(RT_PI / 2.0);
    } else {
      y = 0.0;
    }
  } else {
    y = std::atan2(u0, u1);
  }

  return y;
}

void rt_mldivide_U1d3x3_U2d_JBYZyA3A(const real_T u0[9], const real_T u1[3],
  real_T y[3])
{
  real_T A[9];
  real_T a21;
  real_T maxval;
  int32_T r1;
  int32_T r2;
  int32_T r3;
  std::memcpy(&A[0], &u0[0], 9U * sizeof(real_T));
  r1 = 0;
  r2 = 1;
  r3 = 2;
  maxval = std::abs(u0[0]);
  a21 = std::abs(u0[1]);
  if (a21 > maxval) {
    maxval = a21;
    r1 = 1;
    r2 = 0;
  }

  if (std::abs(u0[2]) > maxval) {
    r1 = 2;
    r2 = 1;
    r3 = 0;
  }

  A[r2] = u0[r2] / u0[r1];
  A[r3] /= A[r1];
  A[r2 + 3] -= A[r1 + 3] * A[r2];
  A[r3 + 3] -= A[r1 + 3] * A[r3];
  A[r2 + 6] -= A[r1 + 6] * A[r2];
  A[r3 + 6] -= A[r1 + 6] * A[r3];
  if (std::abs(A[r3 + 3]) > std::abs(A[r2 + 3])) {
    int32_T rtemp;
    rtemp = r2 + 1;
    r2 = r3;
    r3 = rtemp - 1;
  }

  A[r3 + 3] /= A[r2 + 3];
  A[r3 + 6] -= A[r3 + 3] * A[r2 + 6];
  y[1] = u1[r2] - u1[r1] * A[r2];
  y[2] = (u1[r3] - u1[r1] * A[r3]) - A[r3 + 3] * y[1];
  y[2] /= A[r3 + 6];
  y[0] = u1[r1] - A[r1 + 6] * y[2];
  y[1] -= A[r2 + 6] * y[2];
  y[1] /= A[r2 + 3];
  y[0] -= A[r1 + 3] * y[1];
  y[0] /= A[r1];
}

/* Model step function for TID0 */
void multirotor0::step0()              /* Sample time: [0.0s, 0.0s] */
{
  /* local scratch DWork variables */
  int32_T ForEach_itr;
  real_T rtb_ImpAsg_InsertedFor_Motor_fo[12];
  real_T rtb_ImpAsg_InsertedFor_Motor_mo[12];
  real_T Product_tmp[9];
  real_T rtb_VectorConcatenate[9];
  real_T rtb_Divide[4];
  real_T rtb_ImpAsg_InsertedFor_RPM_moto[4];
  real_T rtb_Sum_a[3];
  real_T rtb_TrueairspeedBodyaxes[3];
  real_T rtb_TrueairspeedBodyaxes_b[3];
  real_T rtb_TrueairspeedBodyaxes_m[3];
  real_T VectorConcatenate;
  real_T VectorConcatenate_0;
  real_T VectorConcatenate_1;
  real_T VectorConcatenate_tmp;
  real_T cphi;
  real_T cpsi;
  real_T ctheta;
  real_T phi;
  real_T psi;
  real_T q1;
  real_T rtb_Airspeeddirectionintherot_0;
  real_T rtb_Product9_idx_0;
  real_T rtb_VectorConcatenate_tmp;
  real_T rtb_VectorConcatenate_tmp_0;
  real_T rtb_VectorConcatenate_tmp_1;
  real_T rtb_VectorConcatenate_tmp_2;
  real_T rtb_VectorConcatenate_tmp_3;
  real_T theta;
  int32_T i;
  int8_T rtAction;
  if (rtmIsMajorTimeStep((&multirotor0_M))) {
    /* set solver stop time */
    rtsiSetSolverStopTime(&(&multirotor0_M)->solverInfo,(((&multirotor0_M)
      ->Timing.clockTick0+1)*(&multirotor0_M)->Timing.stepSize0));

    /* Update the flag to indicate when data transfers from
     *  Sample time: [0.001s, 0.0s] to Sample time: [0.002s, 0.0s]  */
    ((&multirotor0_M)->Timing.RateInteraction.TID1_2)++;
    if (((&multirotor0_M)->Timing.RateInteraction.TID1_2) > 1) {
      (&multirotor0_M)->Timing.RateInteraction.TID1_2 = 0;
    }
  }                                    /* end MajorTimeStep */

  /* Update absolute time of base rate at minor time step */
  if (rtmIsMinorTimeStep((&multirotor0_M))) {
    (&multirotor0_M)->Timing.t[0] = rtsiGetT(&(&multirotor0_M)->solverInfo);
  }

  /* Outputs for Atomic SubSystem: '<Root>/multirotor' */
  if (rtmIsMajorTimeStep((&multirotor0_M))) {
    /* MATLAB Function: '<S8>/MATLAB Function' */
    multirotor0_B.quat_output[0] = 1.0;
    multirotor0_B.quat_output[1] = 0.0;
    multirotor0_B.quat_output[2] = 0.0;
    multirotor0_B.quat_output[3] = 0.0;
  }

  /* Integrator: '<S8>/Q-Integrator' */
  if (multirotor0_DW.QIntegrator_IWORK != 0) {
    multirotor0_X.QIntegrator_CSTATE[0] = multirotor0_B.quat_output[0];
    multirotor0_X.QIntegrator_CSTATE[1] = multirotor0_B.quat_output[1];
    multirotor0_X.QIntegrator_CSTATE[2] = multirotor0_B.quat_output[2];
    multirotor0_X.QIntegrator_CSTATE[3] = multirotor0_B.quat_output[3];
  }

  /* Sqrt: '<S22>/Sqrt' incorporates:
   *  Integrator: '<S8>/Q-Integrator'
   *  Product: '<S23>/Product'
   */
  cphi = std::sqrt(((multirotor0_X.QIntegrator_CSTATE[0] *
                     multirotor0_X.QIntegrator_CSTATE[0] +
                     multirotor0_X.QIntegrator_CSTATE[1] *
                     multirotor0_X.QIntegrator_CSTATE[1]) +
                    multirotor0_X.QIntegrator_CSTATE[2] *
                    multirotor0_X.QIntegrator_CSTATE[2]) +
                   multirotor0_X.QIntegrator_CSTATE[3] *
                   multirotor0_X.QIntegrator_CSTATE[3]);

  /* Product: '<S19>/Divide' incorporates:
   *  Integrator: '<S8>/Q-Integrator'
   */
  rtb_Divide[0] = multirotor0_X.QIntegrator_CSTATE[0] / cphi;
  rtb_Divide[1] = multirotor0_X.QIntegrator_CSTATE[1] / cphi;
  rtb_Divide[2] = multirotor0_X.QIntegrator_CSTATE[2] / cphi;
  rtb_Divide[3] = multirotor0_X.QIntegrator_CSTATE[3] / cphi;

  /* Product: '<S24>/Product' incorporates:
   *  Product: '<S25>/Product'
   */
  rtb_VectorConcatenate_tmp_0 = rtb_Divide[0] * rtb_Divide[0];

  /* Product: '<S24>/Product2' incorporates:
   *  Product: '<S25>/Product2'
   */
  rtb_VectorConcatenate_tmp_1 = rtb_Divide[1] * rtb_Divide[1];

  /* Product: '<S24>/Product3' incorporates:
   *  Product: '<S25>/Product3'
   *  Product: '<S26>/Product3'
   */
  cphi = rtb_Divide[2] * rtb_Divide[2];

  /* Product: '<S24>/Product4' incorporates:
   *  Product: '<S25>/Product4'
   *  Product: '<S26>/Product4'
   */
  phi = rtb_Divide[3] * rtb_Divide[3];

  /* Sum: '<S24>/Add' incorporates:
   *  Fcn: '<S9>/Fcn4'
   *  Product: '<S24>/Product'
   *  Product: '<S24>/Product2'
   *  Product: '<S24>/Product3'
   *  Product: '<S24>/Product4'
   */
  rtb_VectorConcatenate_tmp_3 = ((rtb_VectorConcatenate_tmp_0 +
    rtb_VectorConcatenate_tmp_1) - cphi) - phi;
  rtb_VectorConcatenate[0] = rtb_VectorConcatenate_tmp_3;

  /* Product: '<S29>/Product' incorporates:
   *  Product: '<S27>/Product'
   */
  rtb_VectorConcatenate_tmp = rtb_Divide[1] * rtb_Divide[2];

  /* Product: '<S29>/Product2' incorporates:
   *  Product: '<S27>/Product2'
   */
  ctheta = rtb_Divide[0] * rtb_Divide[3];

  /* Gain: '<S29>/Gain' incorporates:
   *  Product: '<S29>/Product'
   *  Product: '<S29>/Product2'
   *  Sum: '<S29>/Add'
   */
  rtb_VectorConcatenate[1] = (rtb_VectorConcatenate_tmp - ctheta) * 2.0;

  /* Product: '<S31>/Product' incorporates:
   *  Product: '<S28>/Product'
   */
  rtb_VectorConcatenate_tmp_2 = rtb_Divide[1] * rtb_Divide[3];

  /* Product: '<S31>/Product2' incorporates:
   *  Product: '<S28>/Product2'
   */
  theta = rtb_Divide[0] * rtb_Divide[2];

  /* Gain: '<S31>/Gain' incorporates:
   *  Product: '<S31>/Product'
   *  Product: '<S31>/Product2'
   *  Sum: '<S31>/Add'
   */
  rtb_VectorConcatenate[2] = (rtb_VectorConcatenate_tmp_2 + theta) * 2.0;

  /* Sum: '<S27>/Add' incorporates:
   *  Fcn: '<S9>/Fcn2'
   */
  rtb_VectorConcatenate_tmp += ctheta;

  /* Gain: '<S27>/Gain' incorporates:
   *  Sum: '<S27>/Add'
   */
  rtb_VectorConcatenate[3] = rtb_VectorConcatenate_tmp * 2.0;

  /* Sum: '<S25>/Add' incorporates:
   *  Sum: '<S26>/Add'
   */
  rtb_VectorConcatenate_tmp_0 -= rtb_VectorConcatenate_tmp_1;
  rtb_VectorConcatenate[4] = (rtb_VectorConcatenate_tmp_0 + cphi) - phi;

  /* Product: '<S32>/Product' incorporates:
   *  Product: '<S30>/Product'
   */
  rtb_VectorConcatenate_tmp_1 = rtb_Divide[2] * rtb_Divide[3];

  /* Product: '<S32>/Product2' incorporates:
   *  Product: '<S30>/Product2'
   */
  ctheta = rtb_Divide[0] * rtb_Divide[1];

  /* Gain: '<S32>/Gain' incorporates:
   *  Product: '<S32>/Product'
   *  Product: '<S32>/Product2'
   *  Sum: '<S32>/Add'
   */
  rtb_VectorConcatenate[5] = (rtb_VectorConcatenate_tmp_1 - ctheta) * 2.0;

  /* Sum: '<S28>/Add' incorporates:
   *  Fcn: '<S9>/Fcn1'
   */
  rtb_VectorConcatenate_tmp_2 -= theta;

  /* Gain: '<S28>/Gain' incorporates:
   *  Sum: '<S28>/Add'
   */
  rtb_VectorConcatenate[6] = rtb_VectorConcatenate_tmp_2 * 2.0;

  /* Sum: '<S30>/Add' incorporates:
   *  Fcn: '<S9>/Fcn'
   */
  rtb_VectorConcatenate_tmp_1 += ctheta;

  /* Gain: '<S30>/Gain' incorporates:
   *  Sum: '<S30>/Add'
   */
  rtb_VectorConcatenate[7] = rtb_VectorConcatenate_tmp_1 * 2.0;

  /* Sum: '<S26>/Add' incorporates:
   *  Fcn: '<S9>/Fcn3'
   */
  rtb_VectorConcatenate_tmp_0 = (rtb_VectorConcatenate_tmp_0 - cphi) + phi;
  rtb_VectorConcatenate[8] = rtb_VectorConcatenate_tmp_0;
  for (i = 0; i < 3; i++) {
    /* Math: '<S5>/Math Function2' incorporates:
     *  Concatenate: '<S33>/Vector Concatenate'
     *  Math: '<S6>/Math Function2'
     */
    Product_tmp[3 * i] = rtb_VectorConcatenate[i];
    Product_tmp[3 * i + 1] = rtb_VectorConcatenate[i + 3];
    Product_tmp[3 * i + 2] = rtb_VectorConcatenate[i + 6];
  }

  /* Integrator: '<S2>/V_b' incorporates:
   *  Math: '<S5>/Math Function2'
   */
  cphi = multirotor0_X.V_b_CSTATE[1];
  phi = multirotor0_X.V_b_CSTATE[0];
  ctheta = multirotor0_X.V_b_CSTATE[2];
  for (i = 0; i < 3; i++) {
    /* Product: '<S5>/Product' incorporates:
     *  Integrator: '<S2>/V_b'
     *  Math: '<S5>/Math Function2'
     */
    multirotor0_B.Product[i] = (Product_tmp[i + 3] * cphi + Product_tmp[i] * phi)
      + Product_tmp[i + 6] * ctheta;
  }

  /* RateTransition: '<S1>/Rate Transition1' */
  if (rtmIsMajorTimeStep((&multirotor0_M)) && ((&multirotor0_M)
       ->Timing.RateInteraction.TID1_2 == 1)) {
    /* RateTransition: '<S1>/Rate Transition1' */
    multirotor0_B.RateTransition1[0] = multirotor0_DW.RateTransition1_Buffer0[0];
    multirotor0_B.RateTransition1[1] = multirotor0_DW.RateTransition1_Buffer0[1];
    multirotor0_B.RateTransition1[2] = multirotor0_DW.RateTransition1_Buffer0[2];
    multirotor0_B.RateTransition1[3] = multirotor0_DW.RateTransition1_Buffer0[3];
  }

  /* End of RateTransition: '<S1>/Rate Transition1' */

  /* Product: '<S116>/Product' incorporates:
   *  Inport: '<Root>/wind'
   */
  cphi = multirotor0_U.Wind_i[1];
  phi = multirotor0_U.Wind_i[0];
  ctheta = multirotor0_U.Wind_i[2];
  for (i = 0; i < 3; i++) {
    /* Product: '<S55>/Product' incorporates:
     *  Concatenate: '<S33>/Vector Concatenate'
     */
    theta = (rtb_VectorConcatenate[i + 3] * cphi + rtb_VectorConcatenate[i] *
             phi) + rtb_VectorConcatenate[i + 6] * ctheta;
    rtb_TrueairspeedBodyaxes_b[i] = theta;

    /* Sum: '<S57>/Sum1' incorporates:
     *  Integrator: '<S2>/V_b'
     */
    rtb_TrueairspeedBodyaxes[i] = multirotor0_X.V_b_CSTATE[i] - theta;
  }

  /* End of Product: '<S116>/Product' */

  /* Outputs for Iterator SubSystem: '<S38>/For Each Subsystem' incorporates:
   *  ForEach: '<S56>/For Each'
   */
  for (ForEach_itr = 0; ForEach_itr < 4; ForEach_itr++) {
    /* ForEachSliceSelector generated from: '<S56>/MotorMatrix_real' incorporates:
     *  Constant: '<S3>/Constant'
     *  RelationalOperator: '<S62>/Relational Operator'
     *  RelationalOperator: '<S66>/LowerRelop1'
     */
    q1 = multirotor0_ConstP.Constant_Value[ForEach_itr + 44];

    /* Switch: '<S66>/Switch2' incorporates:
     *  Constant: '<S3>/Constant'
     *  ForEachSliceSelector generated from: '<S56>/MotorMatrix_real'
     *  Integrator: '<S62>/Integrator'
     *  RelationalOperator: '<S66>/LowerRelop1'
     */
    if (multirotor0_X.CoreSubsys[ForEach_itr].Integrator_CSTATE > q1) {
      cphi = multirotor0_ConstP.Constant_Value[ForEach_itr + 44];
    } else {
      /* RelationalOperator: '<S66>/UpperRelop' incorporates:
       *  Switch: '<S66>/Switch'
       */
      cphi = multirotor0_ConstP.Constant_Value[ForEach_itr + 40];

      /* Switch: '<S66>/Switch' incorporates:
       *  RelationalOperator: '<S66>/UpperRelop'
       */
      if (!(multirotor0_X.CoreSubsys[ForEach_itr].Integrator_CSTATE < cphi)) {
        cphi = multirotor0_X.CoreSubsys[ForEach_itr].Integrator_CSTATE;
      }
    }

    /* End of Switch: '<S66>/Switch2' */
    if (rtmIsMajorTimeStep((&multirotor0_M))) {
      /* Product: '<S58>/Product' incorporates:
       *  Constant: '<S3>/Constant'
       *  ForEachSliceSelector generated from: '<S56>/MotorMatrix_real'
       *  ForEachSliceSelector generated from: '<S56>/RPM_commands'
       *  RateTransition: '<S1>/Rate Transition1'
       */
      multirotor0_B.CoreSubsys[ForEach_itr].Product =
        multirotor0_ConstP.Constant_Value[ForEach_itr + 16] *
        multirotor0_B.RateTransition1[ForEach_itr];
    }

    /* Product: '<S58>/Divide' incorporates:
     *  Constant: '<S3>/Constant'
     *  ForEachSliceSelector generated from: '<S56>/MotorMatrix_real'
     *  Sum: '<S58>/Sum1'
     */
    ctheta = (multirotor0_B.CoreSubsys[ForEach_itr].Product - cphi) /
      multirotor0_ConstP.Constant_Value[ForEach_itr + 20];

    /* Switch: '<S62>/Switch' incorporates:
     *  Constant: '<S3>/Constant'
     *  Constant: '<S64>/Constant'
     *  Constant: '<S65>/Constant'
     *  ForEachSliceSelector generated from: '<S56>/MotorMatrix_real'
     *  Integrator: '<S62>/Integrator'
     *  Logic: '<S62>/Logical Operator'
     *  Logic: '<S62>/Logical Operator1'
     *  Logic: '<S62>/Logical Operator2'
     *  RelationalOperator: '<S62>/Relational Operator'
     *  RelationalOperator: '<S62>/Relational Operator1'
     *  RelationalOperator: '<S64>/Compare'
     *  RelationalOperator: '<S65>/Compare'
     */
    if (((multirotor0_X.CoreSubsys[ForEach_itr].Integrator_CSTATE <= q1) ||
         (ctheta < 0.0)) && ((ctheta > 0.0) ||
         (multirotor0_X.CoreSubsys[ForEach_itr].Integrator_CSTATE >=
          multirotor0_ConstP.Constant_Value[ForEach_itr + 40]))) {
      /* Switch: '<S62>/Switch' */
      multirotor0_B.CoreSubsys[ForEach_itr].Switch = ctheta;
    } else {
      /* Switch: '<S62>/Switch' incorporates:
       *  Constant: '<S62>/Constant'
       */
      multirotor0_B.CoreSubsys[ForEach_itr].Switch = 0.0;
    }

    /* End of Switch: '<S62>/Switch' */

    /* Switch: '<S63>/Switch' */
    multirotor0_B.CoreSubsys[ForEach_itr].Switch_a = 0.0;
    if (rtmIsMajorTimeStep((&multirotor0_M))) {
      /* Gain: '<S60>/Conversion deg to rad' incorporates:
       *  Constant: '<S3>/Constant'
       *  ForEachSliceSelector generated from: '<S56>/MotorMatrix_real'
       */
      phi = 0.017453292519943295 * multirotor0_ConstP.Constant_Value[ForEach_itr];

      /* Abs: '<S60>/Abs' incorporates:
       *  Constant: '<S3>/Constant'
       *  ForEachSliceSelector generated from: '<S56>/MotorMatrix_real'
       */
      ctheta = std::abs(multirotor0_ConstP.Constant_Value[ForEach_itr + 4]);

      /* Sum: '<S60>/Subtract' incorporates:
       *  Constant: '<S3>/Constant'
       *  Constant: '<S3>/Constant1'
       *  ForEachSliceSelector generated from: '<S56>/MotorMatrix_real'
       *  Product: '<S60>/Product4'
       *  Reshape: '<S60>/Reshape'
       *  Trigonometry: '<S60>/Trigonometric Function'
       *  Trigonometry: '<S60>/Trigonometric Function1'
       */
      multirotor0_B.CoreSubsys[ForEach_itr].VectorfromrealCoGtopropellerBod[0] =
        std::cos(phi) * ctheta;
      multirotor0_B.CoreSubsys[ForEach_itr].VectorfromrealCoGtopropellerBod[1] =
        std::sin(phi) * ctheta;
      multirotor0_B.CoreSubsys[ForEach_itr].VectorfromrealCoGtopropellerBod[2] =
        multirotor0_ConstP.Constant_Value[ForEach_itr + 8] - 0.001;

      /* Gain: '<S73>/Conversion deg to rad' incorporates:
       *  Constant: '<S3>/Constant'
       *  ForEachSliceSelector generated from: '<S56>/MotorMatrix_real'
       */
      rtb_Sum_a[0] = multirotor0_ConstP.Constant_Value[ForEach_itr + 48] *
        0.017453292519943295;
      rtb_Sum_a[1] = multirotor0_ConstP.Constant_Value[ForEach_itr + 52] *
        0.017453292519943295;
      rtb_Sum_a[2] = multirotor0_ConstP.Constant_Value[ForEach_itr + 56] *
        0.017453292519943295;

      /* Trigonometry: '<S104>/Trigonometric Function3' incorporates:
       *  Trigonometry: '<S107>/Trigonometric Function3'
       *  Trigonometry: '<S108>/Trigonometric Function'
       *  Trigonometry: '<S110>/Trigonometric Function4'
       *  Trigonometry: '<S111>/Trigonometric Function'
       */
      phi = std::cos(rtb_Sum_a[2]);

      /* Trigonometry: '<S104>/Trigonometric Function1' incorporates:
       *  Trigonometry: '<S105>/Trigonometric Function1'
       *  Trigonometry: '<S109>/Trigonometric Function1'
       *  Trigonometry: '<S112>/Trigonometric Function1'
       */
      ctheta = std::cos(rtb_Sum_a[1]);

      /* Product: '<S104>/Product' incorporates:
       *  Concatenate: '<S113>/Vector Concatenate'
       *  Trigonometry: '<S104>/Trigonometric Function1'
       *  Trigonometry: '<S104>/Trigonometric Function3'
       */
      multirotor0_B.CoreSubsys[ForEach_itr].VectorConcatenate[0] = ctheta * phi;

      /* Trigonometry: '<S107>/Trigonometric Function5' incorporates:
       *  Trigonometry: '<S108>/Trigonometric Function5'
       *  Trigonometry: '<S110>/Trigonometric Function12'
       *  Trigonometry: '<S112>/Trigonometric Function3'
       */
      theta = std::cos(rtb_Sum_a[0]);

      /* Trigonometry: '<S107>/Trigonometric Function1' incorporates:
       *  Trigonometry: '<S106>/Trigonometric Function1'
       *  Trigonometry: '<S110>/Trigonometric Function2'
       */
      cpsi = std::sin(rtb_Sum_a[1]);

      /* Trigonometry: '<S107>/Trigonometric Function12' incorporates:
       *  Trigonometry: '<S109>/Trigonometric Function3'
       *  Trigonometry: '<S110>/Trigonometric Function5'
       *  Trigonometry: '<S111>/Trigonometric Function5'
       */
      psi = std::sin(rtb_Sum_a[0]);

      /* Trigonometry: '<S107>/Trigonometric Function' incorporates:
       *  Trigonometry: '<S105>/Trigonometric Function3'
       *  Trigonometry: '<S108>/Trigonometric Function4'
       *  Trigonometry: '<S110>/Trigonometric Function'
       *  Trigonometry: '<S111>/Trigonometric Function3'
       */
      q1 = std::sin(rtb_Sum_a[2]);

      /* Product: '<S107>/Product' incorporates:
       *  Product: '<S108>/Product1'
       *  Trigonometry: '<S107>/Trigonometric Function1'
       *  Trigonometry: '<S107>/Trigonometric Function12'
       */
      rtb_Product9_idx_0 = psi * cpsi;

      /* Sum: '<S107>/Sum' incorporates:
       *  Concatenate: '<S113>/Vector Concatenate'
       *  Product: '<S107>/Product'
       *  Product: '<S107>/Product1'
       *  Trigonometry: '<S107>/Trigonometric Function'
       *  Trigonometry: '<S107>/Trigonometric Function5'
       */
      multirotor0_B.CoreSubsys[ForEach_itr].VectorConcatenate[1] =
        rtb_Product9_idx_0 * phi - theta * q1;

      /* Product: '<S110>/Product1' incorporates:
       *  Product: '<S111>/Product'
       */
      VectorConcatenate_tmp = theta * cpsi;

      /* Sum: '<S110>/Sum' incorporates:
       *  Concatenate: '<S113>/Vector Concatenate'
       *  Product: '<S110>/Product1'
       *  Product: '<S110>/Product2'
       */
      multirotor0_B.CoreSubsys[ForEach_itr].VectorConcatenate[2] =
        VectorConcatenate_tmp * phi + psi * q1;

      /* Product: '<S105>/Product' incorporates:
       *  Concatenate: '<S113>/Vector Concatenate'
       */
      multirotor0_B.CoreSubsys[ForEach_itr].VectorConcatenate[3] = ctheta * q1;

      /* Sum: '<S108>/Sum' incorporates:
       *  Concatenate: '<S113>/Vector Concatenate'
       *  Product: '<S108>/Product1'
       *  Product: '<S108>/Product2'
       */
      multirotor0_B.CoreSubsys[ForEach_itr].VectorConcatenate[4] =
        rtb_Product9_idx_0 * q1 + theta * phi;

      /* Sum: '<S111>/Sum' incorporates:
       *  Concatenate: '<S113>/Vector Concatenate'
       *  Product: '<S111>/Product'
       *  Product: '<S111>/Product1'
       */
      multirotor0_B.CoreSubsys[ForEach_itr].VectorConcatenate[5] =
        VectorConcatenate_tmp * q1 - psi * phi;

      /* Gain: '<S106>/Gain' incorporates:
       *  Concatenate: '<S113>/Vector Concatenate'
       */
      multirotor0_B.CoreSubsys[ForEach_itr].VectorConcatenate[6] = -cpsi;

      /* Product: '<S109>/Product' incorporates:
       *  Concatenate: '<S113>/Vector Concatenate'
       */
      multirotor0_B.CoreSubsys[ForEach_itr].VectorConcatenate[7] = psi * ctheta;

      /* Product: '<S112>/Product' incorporates:
       *  Concatenate: '<S113>/Vector Concatenate'
       */
      multirotor0_B.CoreSubsys[ForEach_itr].VectorConcatenate[8] = theta *
        ctheta;
    }

    /* Sum: '<S56>/Sum1' incorporates:
     *  Integrator: '<S2>/omega'
     *  Product: '<S70>/Product'
     *  Product: '<S70>/Product1'
     *  Product: '<S70>/Product2'
     *  Product: '<S71>/Product'
     *  Product: '<S71>/Product1'
     *  Product: '<S71>/Product2'
     *  Sum: '<S57>/Sum1'
     *  Sum: '<S59>/Sum'
     */
    rtb_Product9_idx_0 = (multirotor0_X.omega_CSTATE[1] *
                          multirotor0_B.CoreSubsys[ForEach_itr].
                          VectorfromrealCoGtopropellerBod[2] -
                          multirotor0_B.CoreSubsys[ForEach_itr].
                          VectorfromrealCoGtopropellerBod[1] *
                          multirotor0_X.omega_CSTATE[2]) +
      rtb_TrueairspeedBodyaxes[0];
    psi = (multirotor0_B.CoreSubsys[ForEach_itr]
           .VectorfromrealCoGtopropellerBod[0] * multirotor0_X.omega_CSTATE[2] -
           multirotor0_X.omega_CSTATE[0] * multirotor0_B.CoreSubsys[ForEach_itr]
           .VectorfromrealCoGtopropellerBod[2]) + rtb_TrueairspeedBodyaxes[1];
    cpsi = (multirotor0_X.omega_CSTATE[0] * multirotor0_B.CoreSubsys[ForEach_itr]
            .VectorfromrealCoGtopropellerBod[1] -
            multirotor0_B.CoreSubsys[ForEach_itr].
            VectorfromrealCoGtopropellerBod[0] * multirotor0_X.omega_CSTATE[1])
      + rtb_TrueairspeedBodyaxes[2];

    /* Product: '<S73>/Product' */
    for (i = 0; i < 3; i++) {
      /* Product: '<S73>/Product' incorporates:
       *  Concatenate: '<S113>/Vector Concatenate'
       */
      rtb_Sum_a[i] = (multirotor0_B.CoreSubsys[ForEach_itr].VectorConcatenate[i
                      + 3] * psi + multirotor0_B.CoreSubsys[ForEach_itr].
                      VectorConcatenate[i] * rtb_Product9_idx_0) +
        multirotor0_B.CoreSubsys[ForEach_itr].VectorConcatenate[i + 6] * cpsi;
    }

    /* End of Product: '<S73>/Product' */

    /* Gain: '<S88>/Gain' */
    multirotor0_B.CoreSubsys[ForEach_itr].Climbspeedv_c = -rtb_Sum_a[2];
    if (rtmIsMajorTimeStep((&multirotor0_M))) {
      /* Outputs for IfAction SubSystem: '<S89>/Vortex ring state -2 <= vc//vh < 0 ' incorporates:
       *  ActionPort: '<S97>/Action Port'
       */
      /* If: '<S89>/If' incorporates:
       *  Constant: '<S76>/Induced velocity at hover'
       *  Product: '<S89>/Divide'
       *  Product: '<S97>/Divide'
       */
      q1 = multirotor0_B.CoreSubsys[ForEach_itr].Climbspeedv_c / 4.0;

      /* End of Outputs for SubSystem: '<S89>/Vortex ring state -2 <= vc//vh < 0 ' */
      if (rtsiIsModeUpdateTimeStep(&(&multirotor0_M)->solverInfo)) {
        if (q1 >= 0.0) {
          rtAction = 0;
        } else if (q1 >= -2.0) {
          rtAction = 1;
        } else {
          rtAction = 2;
        }

        multirotor0_DW.CoreSubsys[ForEach_itr].If_ActiveSubsystem = rtAction;
      } else {
        rtAction = multirotor0_DW.CoreSubsys[ForEach_itr].If_ActiveSubsystem;
      }

      switch (rtAction) {
       case 0:
        /* Outputs for IfAction SubSystem: '<S89>/Normal working state vc//vh >= 0' incorporates:
         *  ActionPort: '<S96>/Action Port'
         */
        /* Gain: '<S96>/Gain' */
        phi = 0.5 * multirotor0_B.CoreSubsys[ForEach_itr].Climbspeedv_c;

        /* Merge: '<S89>/Merge' incorporates:
         *  Product: '<S96>/Product'
         *  Sqrt: '<S96>/Sqrt'
         *  Sum: '<S96>/Sum'
         *  Sum: '<S96>/Sum1'
         */
        multirotor0_B.CoreSubsys[ForEach_itr].Merge = std::sqrt(phi * phi + 16.0)
          - phi;

        /* End of Outputs for SubSystem: '<S89>/Normal working state vc//vh >= 0' */
        break;

       case 1:
        /* Outputs for IfAction SubSystem: '<S89>/Vortex ring state -2 <= vc//vh < 0 ' incorporates:
         *  ActionPort: '<S97>/Action Port'
         */
        /* Product: '<S97>/Product' */
        ctheta = q1 * q1;

        /* Gain: '<S97>/Gain1' */
        theta = -1.372 * ctheta;

        /* Product: '<S97>/Product1' */
        ctheta *= q1;

        /* Merge: '<S89>/Merge' incorporates:
         *  Constant: '<S97>/Constant'
         *  Constant: '<S97>/Induced velocity at hover'
         *  Gain: '<S97>/Gain'
         *  Gain: '<S97>/Gain2'
         *  Gain: '<S97>/Gain3'
         *  Product: '<S97>/Product2'
         *  Product: '<S97>/Product3'
         *  Sum: '<S97>/Add'
         */
        multirotor0_B.CoreSubsys[ForEach_itr].Merge = ((((-1.125 * q1 + 1.0) +
          theta) + -1.718 * ctheta) + ctheta * q1 * -0.655) * 4.0;

        /* End of Outputs for SubSystem: '<S89>/Vortex ring state -2 <= vc//vh < 0 ' */
        break;

       default:
        /* Outputs for IfAction SubSystem: '<S89>/Windmill braking state vc//vh < -2' incorporates:
         *  ActionPort: '<S98>/Action Port'
         */
        /* Gain: '<S98>/Gain' */
        phi = 0.5 * multirotor0_B.CoreSubsys[ForEach_itr].Climbspeedv_c;

        /* Merge: '<S89>/Merge' incorporates:
         *  Product: '<S98>/Product'
         *  Sqrt: '<S98>/Sqrt'
         *  Sum: '<S98>/Sum'
         *  Sum: '<S98>/Sum1'
         */
        multirotor0_B.CoreSubsys[ForEach_itr].Merge = (0.0 - phi) - std::sqrt
          (phi * phi - 16.0);

        /* End of Outputs for SubSystem: '<S89>/Windmill braking state vc//vh < -2' */
        break;
      }

      /* End of If: '<S89>/If' */
    }

    /* Outputs for IfAction SubSystem: '<S75>/Nonzero airspeed in rotor plane' incorporates:
     *  ActionPort: '<S81>/Action Port'
     */
    /* Outputs for IfAction SubSystem: '<S87>/Nonzero airspeed' incorporates:
     *  ActionPort: '<S90>/Action Port'
     */
    /* If: '<S75>/If' incorporates:
     *  If: '<S87>/If'
     *  Math: '<S95>/transpose'
     *  Product: '<S73>/Product'
     *  Product: '<S85>/Product'
     *  Product: '<S86>/Product'
     *  Product: '<S94>/Product'
     *  Product: '<S95>/Product'
     */
    theta = rtb_Sum_a[0] * rtb_Sum_a[0] + rtb_Sum_a[1] * rtb_Sum_a[1];

    /* End of Outputs for SubSystem: '<S87>/Nonzero airspeed' */
    /* End of Outputs for SubSystem: '<S75>/Nonzero airspeed in rotor plane' */

    /* Sqrt: '<S92>/Sqrt' incorporates:
     *  Math: '<S95>/transpose'
     *  Product: '<S73>/Product'
     *  Product: '<S95>/Product'
     */
    ctheta = std::sqrt(rtb_Sum_a[2] * rtb_Sum_a[2] + theta);

    /* If: '<S87>/If' */
    if (rtsiIsModeUpdateTimeStep(&(&multirotor0_M)->solverInfo)) {
      rtAction = static_cast<int8_T>(!(ctheta == 0.0));
      multirotor0_DW.CoreSubsys[ForEach_itr].If_ActiveSubsystem_l = rtAction;
    } else {
      rtAction = multirotor0_DW.CoreSubsys[ForEach_itr].If_ActiveSubsystem_l;
    }

    if (rtAction == 0) {
      /* Outputs for IfAction SubSystem: '<S87>/Zero airspeed' incorporates:
       *  ActionPort: '<S91>/Action Port'
       */
      if (rtmIsMajorTimeStep((&multirotor0_M))) {
        /* Merge: '<S87>/Merge' incorporates:
         *  Constant: '<S91>/Constant'
         */
        multirotor0_B.CoreSubsys[ForEach_itr].Angleofattackrad = 0.0;
      }

      /* End of Outputs for SubSystem: '<S87>/Zero airspeed' */
    } else {
      /* Outputs for IfAction SubSystem: '<S87>/Nonzero airspeed' incorporates:
       *  ActionPort: '<S90>/Action Port'
       */
      /* Merge: '<S87>/Merge' incorporates:
       *  Product: '<S90>/Divide1'
       *  Sqrt: '<S93>/Sqrt'
       *  Trigonometry: '<S90>/Trigonometric Function'
       */
      multirotor0_B.CoreSubsys[ForEach_itr].Angleofattackrad = std::atan(1.0 /
        std::sqrt(theta) * rtb_Sum_a[2]);

      /* End of Outputs for SubSystem: '<S87>/Nonzero airspeed' */
    }

    /* Product: '<S76>/Divide' incorporates:
     *  Constant: '<S76>/Induced velocity at hover'
     *  Product: '<S76>/Product2'
     *  Sum: '<S76>/Sum2'
     *  Trigonometry: '<S76>/Trigonometric Function'
     */
    phi = 4.0 / (multirotor0_B.CoreSubsys[ForEach_itr].Merge - std::sin
                 (multirotor0_B.CoreSubsys[ForEach_itr].Angleofattackrad) *
                 ctheta);

    /* Product: '<S79>/Product5' incorporates:
     *  Product: '<S78>/Product1'
     */
    q1 = cphi * cphi;

    /* Product: '<S72>/Product7' incorporates:
     *  Constant: '<S3>/Constant'
     *  ForEachSliceSelector generated from: '<S56>/MotorMatrix_real'
     *  Product: '<S79>/Product4'
     *  Product: '<S79>/Product5'
     *  Product: '<S79>/Product6'
     *  Sum: '<S79>/Sum1'
     *  Switch: '<S76>/Switch'
     */
    ctheta = (multirotor0_ConstP.Constant_Value[ForEach_itr + 24] * cphi +
              multirotor0_ConstP.Constant_Value[ForEach_itr + 28] * q1) * phi;

    /* If: '<S75>/If' incorporates:
     *  Sqrt: '<S83>/Sqrt'
     */
    if (rtsiIsModeUpdateTimeStep(&(&multirotor0_M)->solverInfo)) {
      rtAction = static_cast<int8_T>(!(std::sqrt(theta) == 0.0));
      multirotor0_DW.CoreSubsys[ForEach_itr].If_ActiveSubsystem_e = rtAction;
    } else {
      rtAction = multirotor0_DW.CoreSubsys[ForEach_itr].If_ActiveSubsystem_e;
    }

    if (rtAction == 0) {
      /* Outputs for IfAction SubSystem: '<S75>/Zero airspeed in rotor plane' incorporates:
       *  ActionPort: '<S82>/Action Port'
       */
      if (rtmIsMajorTimeStep((&multirotor0_M))) {
        /* Merge: '<S75>/Merge' incorporates:
         *  Constant: '<S82>/Constant'
         */
        multirotor0_B.CoreSubsys[ForEach_itr].NewtiltedthrustdirectionBodyaxe[0]
          = 0.0;

        /* Merge: '<S75>/Merge1' incorporates:
         *  Constant: '<S82>/Constant1'
         */
        multirotor0_B.CoreSubsys[ForEach_itr].Momentinthemotorhubduetobending[0]
          = 0.0;

        /* Merge: '<S75>/Merge' incorporates:
         *  Constant: '<S82>/Constant'
         */
        multirotor0_B.CoreSubsys[ForEach_itr].NewtiltedthrustdirectionBodyaxe[1]
          = 0.0;

        /* Merge: '<S75>/Merge1' incorporates:
         *  Constant: '<S82>/Constant1'
         */
        multirotor0_B.CoreSubsys[ForEach_itr].Momentinthemotorhubduetobending[1]
          = 0.0;

        /* Merge: '<S75>/Merge' incorporates:
         *  Constant: '<S82>/Constant'
         */
        multirotor0_B.CoreSubsys[ForEach_itr].NewtiltedthrustdirectionBodyaxe[2]
          = -1.0;

        /* Merge: '<S75>/Merge1' incorporates:
         *  Constant: '<S82>/Constant1'
         */
        multirotor0_B.CoreSubsys[ForEach_itr].Momentinthemotorhubduetobending[2]
          = 0.0;
      }

      /* End of Outputs for SubSystem: '<S75>/Zero airspeed in rotor plane' */
    } else {
      /* Outputs for IfAction SubSystem: '<S75>/Nonzero airspeed in rotor plane' incorporates:
       *  ActionPort: '<S81>/Action Port'
       */
      /* Sqrt: '<S84>/Sqrt' */
      theta = std::sqrt(theta);

      /* Gain: '<S81>/Conversion deg to rad' incorporates:
       *  Product: '<S81>/Product4'
       */
      cpsi = theta * 0.375 * 0.017453292519943295;

      /* Trigonometry: '<S81>/Trigonometric Function' */
      psi = std::sin(cpsi);

      /* Product: '<S81>/Divide' */
      VectorConcatenate_tmp = rtb_Sum_a[0] / theta;
      rtb_Airspeeddirectionintherot_0 = VectorConcatenate_tmp;

      /* Product: '<S81>/Product2' incorporates:
       *  Gain: '<S81>/Gain'
       *  Product: '<S81>/Divide'
       *  Product: '<S81>/Product'
       */
      rtb_Product9_idx_0 = -VectorConcatenate_tmp * psi;

      /* Product: '<S81>/Divide' */
      VectorConcatenate_tmp = rtb_Sum_a[1] / theta;

      /* Product: '<S81>/Product2' incorporates:
       *  Gain: '<S81>/Gain'
       *  Product: '<S81>/Divide'
       *  Product: '<S81>/Product'
       */
      psi *= -VectorConcatenate_tmp;

      /* Gain: '<S81>/Gain1' incorporates:
       *  Trigonometry: '<S81>/Trigonometric Function1'
       */
      theta = -std::cos(cpsi);

      /* Product: '<S81>/Product3' incorporates:
       *  Constant: '<S81>/Constant'
       *  Constant: '<S81>/Constant1'
       *  Gain: '<S81>/Gain2'
       *  Product: '<S81>/Divide'
       *  Product: '<S81>/Product1'
       */
      VectorConcatenate_tmp = -VectorConcatenate_tmp * 0.23 * cpsi;
      rtb_Airspeeddirectionintherot_0 = rtb_Airspeeddirectionintherot_0 * 0.23 *
        cpsi;
      cpsi *= 0.0;
      for (i = 0; i < 3; i++) {
        /* Product: '<S81>/Product2' incorporates:
         *  Concatenate: '<S113>/Vector Concatenate'
         */
        VectorConcatenate = multirotor0_B.CoreSubsys[ForEach_itr].
          VectorConcatenate[3 * i];
        VectorConcatenate_0 = multirotor0_B.CoreSubsys[ForEach_itr].
          VectorConcatenate[3 * i + 1];
        VectorConcatenate_1 = multirotor0_B.CoreSubsys[ForEach_itr].
          VectorConcatenate[3 * i + 2];

        /* Merge: '<S75>/Merge' incorporates:
         *  Product: '<S81>/Product2'
         *  Reshape: '<S81>/Reshape1'
         */
        multirotor0_B.CoreSubsys[ForEach_itr].NewtiltedthrustdirectionBodyaxe[i]
          = (VectorConcatenate_0 * psi + VectorConcatenate * rtb_Product9_idx_0)
          + VectorConcatenate_1 * theta;

        /* Merge: '<S75>/Merge1' incorporates:
         *  Product: '<S81>/Product3'
         */
        multirotor0_B.CoreSubsys[ForEach_itr].Momentinthemotorhubduetobending[i]
          = (VectorConcatenate_0 * rtb_Airspeeddirectionintherot_0 +
             VectorConcatenate * VectorConcatenate_tmp) + VectorConcatenate_1 *
          cpsi;
      }

      /* End of Outputs for SubSystem: '<S75>/Nonzero airspeed in rotor plane' */
    }

    /* Product: '<S72>/Product9' incorporates:
     *  Merge: '<S75>/Merge'
     */
    rtb_Product9_idx_0 = ctheta * multirotor0_B.CoreSubsys[ForEach_itr].
      NewtiltedthrustdirectionBodyaxe[0];
    cpsi = ctheta * multirotor0_B.CoreSubsys[ForEach_itr].
      NewtiltedthrustdirectionBodyaxe[1];
    psi = ctheta * multirotor0_B.CoreSubsys[ForEach_itr].
      NewtiltedthrustdirectionBodyaxe[2];
    if (rtmIsMajorTimeStep((&multirotor0_M))) {
      for (i = 0; i < 3; i++) {
        /* Product: '<S80>/Product9' incorporates:
         *  Concatenate: '<S113>/Vector Concatenate'
         *  Constant: '<S80>/Constant'
         *  Math: '<S80>/Math Function'
         */
        multirotor0_B.CoreSubsys[ForEach_itr].Product9[i] =
          (multirotor0_B.CoreSubsys[ForEach_itr].VectorConcatenate[3 * i + 1] *
           0.0 + multirotor0_B.CoreSubsys[ForEach_itr].VectorConcatenate[3 * i] *
           0.0) - multirotor0_B.CoreSubsys[ForEach_itr].VectorConcatenate[3 * i
          + 2];
      }

      /* Gain: '<S100>/Gain' incorporates:
       *  Constant: '<S3>/Constant'
       *  ForEachSliceSelector generated from: '<S56>/MotorMatrix_real'
       */
      ctheta = multirotor0_ConstP.Constant_Value[ForEach_itr + 60] * 0.5;

      /* Gain: '<S100>/Gain1' incorporates:
       *  Constant: '<S3>/Constant'
       *  ForEachSliceSelector generated from: '<S56>/MotorMatrix_real'
       *  Product: '<S100>/Product7'
       */
      multirotor0_B.CoreSubsys[ForEach_itr].Gain1 = ctheta * ctheta *
        multirotor0_ConstP.Constant_Value[ForEach_itr + 64] *
        0.58333333333333337;
    }

    /* Gain: '<S77>/Conversion rpm to rad//s' */
    ctheta = 0.10471975511965977 * cphi;

    /* ForEachSliceAssignment generated from: '<S56>/RPM_motor' */
    rtb_ImpAsg_InsertedFor_RPM_moto[ForEach_itr] = cphi;

    /* ForEachSliceSelector generated from: '<S56>/MotorMatrix_real' incorporates:
     *  Constant: '<S3>/Constant'
     *  Product: '<S72>/Product3'
     *  Product: '<S77>/Product5'
     */
    VectorConcatenate_tmp = multirotor0_ConstP.Constant_Value[ForEach_itr + 12];

    /* Product: '<S72>/Product3' incorporates:
     *  Constant: '<S3>/Constant'
     *  ForEachSliceSelector generated from: '<S56>/MotorMatrix_real'
     *  Product: '<S78>/Product'
     *  Product: '<S78>/Product1'
     *  Sum: '<S78>/Sum'
     */
    theta = (multirotor0_ConstP.Constant_Value[ForEach_itr + 32] * cphi +
             multirotor0_ConstP.Constant_Value[ForEach_itr + 36] * q1) *
      VectorConcatenate_tmp;

    /* Product: '<S77>/Product5' */
    q1 = VectorConcatenate_tmp * multirotor0_B.CoreSubsys[ForEach_itr].Gain1;

    /* ForEachSliceAssignment generated from: '<S56>/Motor_moment' incorporates:
     *  Integrator: '<S2>/omega'
     *  Merge: '<S75>/Merge1'
     *  Product: '<S101>/Product'
     *  Product: '<S102>/Product'
     *  Product: '<S114>/Product'
     *  Product: '<S115>/Product'
     *  Product: '<S72>/Product3'
     *  Product: '<S72>/Product8'
     *  Product: '<S77>/Product5'
     *  Product: '<S80>/Product9'
     *  Sum: '<S61>/Add'
     *  Sum: '<S74>/Sum'
     *  Sum: '<S99>/Sum'
     *  Switch: '<S76>/Switch'
     */
    rtb_ImpAsg_InsertedFor_Motor_mo[3 * ForEach_itr] =
      ((multirotor0_X.omega_CSTATE[1] * multirotor0_B.CoreSubsys[ForEach_itr].
        NewtiltedthrustdirectionBodyaxe[2] -
        multirotor0_B.CoreSubsys[ForEach_itr].NewtiltedthrustdirectionBodyaxe[1]
        * multirotor0_X.omega_CSTATE[2]) * q1 * ctheta + (theta *
        multirotor0_B.CoreSubsys[ForEach_itr].Product9[0] * phi +
        multirotor0_B.CoreSubsys[ForEach_itr].Momentinthemotorhubduetobending[0]))
      + (multirotor0_B.CoreSubsys[ForEach_itr].VectorfromrealCoGtopropellerBod[1]
         * psi - cpsi * multirotor0_B.CoreSubsys[ForEach_itr].
         VectorfromrealCoGtopropellerBod[2]);

    /* ForEachSliceAssignment generated from: '<S56>/Motor_force' incorporates:
     *  Product: '<S72>/Product9'
     */
    rtb_ImpAsg_InsertedFor_Motor_fo[3 * ForEach_itr] = rtb_Product9_idx_0;

    /* ForEachSliceAssignment generated from: '<S56>/Motor_moment' incorporates:
     *  ForEachSliceAssignment generated from: '<S56>/Motor_force'
     *  Integrator: '<S2>/omega'
     *  Merge: '<S75>/Merge1'
     *  Product: '<S101>/Product1'
     *  Product: '<S102>/Product1'
     *  Product: '<S114>/Product1'
     *  Product: '<S115>/Product1'
     *  Product: '<S72>/Product3'
     *  Product: '<S72>/Product8'
     *  Product: '<S77>/Product5'
     *  Product: '<S80>/Product9'
     *  Sum: '<S61>/Add'
     *  Sum: '<S74>/Sum'
     *  Sum: '<S99>/Sum'
     *  Switch: '<S76>/Switch'
     */
    i = 3 * ForEach_itr + 1;
    rtb_ImpAsg_InsertedFor_Motor_mo[i] = ((multirotor0_B.CoreSubsys[ForEach_itr]
      .NewtiltedthrustdirectionBodyaxe[0] * multirotor0_X.omega_CSTATE[2] -
      multirotor0_X.omega_CSTATE[0] * multirotor0_B.CoreSubsys[ForEach_itr].
      NewtiltedthrustdirectionBodyaxe[2]) * q1 * ctheta + (theta *
      multirotor0_B.CoreSubsys[ForEach_itr].Product9[1] * phi +
      multirotor0_B.CoreSubsys[ForEach_itr].Momentinthemotorhubduetobending[1]))
      + (rtb_Product9_idx_0 * multirotor0_B.CoreSubsys[ForEach_itr].
         VectorfromrealCoGtopropellerBod[2] -
         multirotor0_B.CoreSubsys[ForEach_itr].VectorfromrealCoGtopropellerBod[0]
         * psi);

    /* ForEachSliceAssignment generated from: '<S56>/Motor_force' incorporates:
     *  Product: '<S72>/Product9'
     */
    rtb_ImpAsg_InsertedFor_Motor_fo[i] = cpsi;

    /* ForEachSliceAssignment generated from: '<S56>/Motor_moment' incorporates:
     *  ForEachSliceAssignment generated from: '<S56>/Motor_force'
     *  Integrator: '<S2>/omega'
     *  Merge: '<S75>/Merge1'
     *  Product: '<S101>/Product2'
     *  Product: '<S102>/Product2'
     *  Product: '<S114>/Product2'
     *  Product: '<S115>/Product2'
     *  Product: '<S72>/Product3'
     *  Product: '<S72>/Product8'
     *  Product: '<S77>/Product5'
     *  Product: '<S80>/Product9'
     *  Sum: '<S61>/Add'
     *  Sum: '<S74>/Sum'
     *  Sum: '<S99>/Sum'
     *  Switch: '<S76>/Switch'
     */
    i = 3 * ForEach_itr + 2;
    rtb_ImpAsg_InsertedFor_Motor_mo[i] = ((multirotor0_X.omega_CSTATE[0] *
      multirotor0_B.CoreSubsys[ForEach_itr].NewtiltedthrustdirectionBodyaxe[1] -
      multirotor0_B.CoreSubsys[ForEach_itr].NewtiltedthrustdirectionBodyaxe[0] *
      multirotor0_X.omega_CSTATE[1]) * q1 * ctheta + (theta *
      multirotor0_B.CoreSubsys[ForEach_itr].Product9[2] * phi +
      multirotor0_B.CoreSubsys[ForEach_itr].Momentinthemotorhubduetobending[2]))
      + (multirotor0_B.CoreSubsys[ForEach_itr].VectorfromrealCoGtopropellerBod[0]
         * cpsi - rtb_Product9_idx_0 * multirotor0_B.CoreSubsys[ForEach_itr].
         VectorfromrealCoGtopropellerBod[1]);

    /* ForEachSliceAssignment generated from: '<S56>/Motor_force' incorporates:
     *  Product: '<S72>/Product9'
     */
    rtb_ImpAsg_InsertedFor_Motor_fo[i] = psi;
  }

  /* End of Outputs for SubSystem: '<S38>/For Each Subsystem' */

  /* Sum: '<S38>/Sum of Elements' incorporates:
   *  ForEachSliceAssignment generated from: '<S56>/Motor_force'
   *  Sum: '<S16>/Sum'
   */
  for (i = 0; i < 3; i++) {
    rtb_Sum_a[i] = ((rtb_ImpAsg_InsertedFor_Motor_fo[i + 3] +
                     rtb_ImpAsg_InsertedFor_Motor_fo[i]) +
                    rtb_ImpAsg_InsertedFor_Motor_fo[i + 6]) +
      rtb_ImpAsg_InsertedFor_Motor_fo[i + 9];
  }

  /* End of Sum: '<S38>/Sum of Elements' */
  if (rtmIsMajorTimeStep((&multirotor0_M))) {
    /* Product: '<S37>/Product1' incorporates:
     *  Constant: '<S37>/Gravity (Inertial axes)'
     *  Constant: '<S3>/Constant2'
     */
    multirotor0_B.ForceofgravityInertialaxes[0] = 0.0;
    multirotor0_B.ForceofgravityInertialaxes[1] = 0.0;
    multirotor0_B.ForceofgravityInertialaxes[2] = 5.3936575;
  }

  /* Sum: '<S40>/Sum1' incorporates:
   *  Integrator: '<S2>/V_b'
   *  Product: '<S55>/Product'
   */
  rtb_TrueairspeedBodyaxes_b[0] = multirotor0_X.V_b_CSTATE[0] -
    rtb_TrueairspeedBodyaxes_b[0];
  rtb_TrueairspeedBodyaxes_b[1] = multirotor0_X.V_b_CSTATE[1] -
    rtb_TrueairspeedBodyaxes_b[1];
  rtb_TrueairspeedBodyaxes_b[2] = multirotor0_X.V_b_CSTATE[2] -
    rtb_TrueairspeedBodyaxes_b[2];

  /* If: '<S39>/If' incorporates:
   *  Math: '<S54>/transpose'
   *  Product: '<S54>/Product'
   *  Sqrt: '<S43>/Sqrt'
   *  Sum: '<S40>/Sum1'
   */
  if (rtsiIsModeUpdateTimeStep(&(&multirotor0_M)->solverInfo)) {
    rtAction = static_cast<int8_T>(!(std::sqrt((rtb_TrueairspeedBodyaxes_b[0] *
      rtb_TrueairspeedBodyaxes_b[0] + rtb_TrueairspeedBodyaxes_b[1] *
      rtb_TrueairspeedBodyaxes_b[1]) + rtb_TrueairspeedBodyaxes_b[2] *
      rtb_TrueairspeedBodyaxes_b[2]) == 0.0));
    multirotor0_DW.If_ActiveSubsystem = rtAction;
  } else {
    rtAction = multirotor0_DW.If_ActiveSubsystem;
  }

  if (rtAction == 0) {
    /* Outputs for IfAction SubSystem: '<S39>/Zero airspeed' incorporates:
     *  ActionPort: '<S42>/Action Port'
     */
    if (rtmIsMajorTimeStep((&multirotor0_M))) {
      /* Merge: '<S39>/Merge' incorporates:
       *  Constant: '<S42>/Constant'
       */
      multirotor0_B.Forceagainstdirectionofmotiondu[0] = 0.0;
      multirotor0_B.Forceagainstdirectionofmotiondu[1] = 0.0;
      multirotor0_B.Forceagainstdirectionofmotiondu[2] = 0.0;
    }

    /* End of Outputs for SubSystem: '<S39>/Zero airspeed' */
  } else {
    /* Outputs for IfAction SubSystem: '<S39>/Nonzero airspeed' incorporates:
     *  ActionPort: '<S41>/Action Port'
     */
    /* Product: '<S49>/Divide' incorporates:
     *  Constant: '<S3>/Surface area params'
     */
    cphi = rtb_TrueairspeedBodyaxes_b[0] / 0.06;

    /* Product: '<S49>/Product' */
    phi = cphi * cphi;

    /* Product: '<S49>/Divide1' incorporates:
     *  Constant: '<S3>/Surface area params'
     */
    cphi = rtb_TrueairspeedBodyaxes_b[1] / 0.06;

    /* Product: '<S49>/Product1' */
    ctheta = cphi * cphi;

    /* Product: '<S49>/Divide2' incorporates:
     *  Constant: '<S3>/Surface area params'
     */
    cphi = rtb_TrueairspeedBodyaxes_b[2] / 0.06;

    /* Sum: '<S49>/Add' incorporates:
     *  Product: '<S49>/Product2'
     */
    cphi = (phi + ctheta) + cphi * cphi;

    /* Sqrt: '<S49>/Reciprocal Sqrt' */
    if (cphi > 0.0) {
      if (std::isinf(cphi)) {
        cphi = 0.0;
      } else {
        cphi = 1.0 / std::sqrt(cphi);
      }
    } else if (cphi == 0.0) {
      cphi = (rtInf);
    } else {
      cphi = (rtNaN);
    }

    /* End of Sqrt: '<S49>/Reciprocal Sqrt' */

    /* Product: '<S50>/Product' incorporates:
     *  Sum: '<S40>/Sum1'
     */
    phi = rtb_TrueairspeedBodyaxes_b[0] * cphi;

    /* Product: '<S52>/Product' incorporates:
     *  Math: '<S52>/transpose'
     *  Product: '<S50>/Product'
     */
    ctheta = phi * phi;

    /* Product: '<S50>/Product' incorporates:
     *  Sum: '<S40>/Sum1'
     */
    phi = rtb_TrueairspeedBodyaxes_b[1] * cphi;

    /* Product: '<S52>/Product' incorporates:
     *  Math: '<S52>/transpose'
     *  Product: '<S50>/Product'
     */
    ctheta += phi * phi;

    /* Product: '<S50>/Product' incorporates:
     *  Sum: '<S40>/Sum1'
     */
    phi = rtb_TrueairspeedBodyaxes_b[2] * cphi;

    /* Product: '<S53>/Product' incorporates:
     *  Product: '<S48>/Product'
     *  Product: '<S50>/Product'
     *  Sum: '<S40>/Sum1'
     */
    q1 = (rtb_TrueairspeedBodyaxes_b[0] * rtb_TrueairspeedBodyaxes_b[0] +
          rtb_TrueairspeedBodyaxes_b[1] * rtb_TrueairspeedBodyaxes_b[1]) +
      rtb_TrueairspeedBodyaxes_b[2] * rtb_TrueairspeedBodyaxes_b[2];

    /* Abs: '<S41>/Abs' incorporates:
     *  Constant: '<S41>/Constant'
     *  Constant: '<S41>/Constant1'
     *  Constant: '<S41>/Constant2'
     *  Math: '<S52>/transpose'
     *  Product: '<S41>/Product'
     *  Product: '<S50>/Product'
     *  Product: '<S52>/Product'
     *  Product: '<S53>/Product'
     *  Sqrt: '<S51>/Sqrt'
     */
    phi = std::abs(q1 * 0.6125 * 0.4 * std::sqrt(phi * phi + ctheta));

    /* Sqrt: '<S47>/Sqrt' */
    cphi = std::sqrt(q1);

    /* Merge: '<S39>/Merge' incorporates:
     *  Gain: '<S41>/Drag force opposes direction of airspeed'
     *  Product: '<S41>/Product1'
     *  Product: '<S44>/Divide'
     *  Sum: '<S40>/Sum1'
     */
    multirotor0_B.Forceagainstdirectionofmotiondu[0] =
      -(rtb_TrueairspeedBodyaxes_b[0] / cphi * phi);
    multirotor0_B.Forceagainstdirectionofmotiondu[1] =
      -(rtb_TrueairspeedBodyaxes_b[1] / cphi * phi);
    multirotor0_B.Forceagainstdirectionofmotiondu[2] =
      -(rtb_TrueairspeedBodyaxes_b[2] / cphi * phi);

    /* End of Outputs for SubSystem: '<S39>/Nonzero airspeed' */
  }

  /* End of If: '<S39>/If' */

  /* Sum: '<S11>/Sum' incorporates:
   *  Integrator: '<S2>/V_b'
   *  Integrator: '<S2>/omega'
   *  Product: '<S34>/Product'
   *  Product: '<S34>/Product1'
   *  Product: '<S34>/Product2'
   *  Product: '<S35>/Product'
   *  Product: '<S35>/Product1'
   *  Product: '<S35>/Product2'
   */
  rtb_TrueairspeedBodyaxes[0] = multirotor0_X.omega_CSTATE[1] *
    multirotor0_X.V_b_CSTATE[2];
  rtb_TrueairspeedBodyaxes[1] = multirotor0_X.V_b_CSTATE[0] *
    multirotor0_X.omega_CSTATE[2];
  rtb_TrueairspeedBodyaxes[2] = multirotor0_X.omega_CSTATE[0] *
    multirotor0_X.V_b_CSTATE[1];
  rtb_TrueairspeedBodyaxes_m[0] = multirotor0_X.V_b_CSTATE[1] *
    multirotor0_X.omega_CSTATE[2];
  rtb_TrueairspeedBodyaxes_m[1] = multirotor0_X.omega_CSTATE[0] *
    multirotor0_X.V_b_CSTATE[2];
  rtb_TrueairspeedBodyaxes_m[2] = multirotor0_X.V_b_CSTATE[0] *
    multirotor0_X.omega_CSTATE[1];

  /* Product: '<S37>/Product' */
  cphi = multirotor0_B.ForceofgravityInertialaxes[1];
  phi = multirotor0_B.ForceofgravityInertialaxes[0];
  ctheta = multirotor0_B.ForceofgravityInertialaxes[2];

  /* Integrator: '<S2>/omega' incorporates:
   *  Constant: '<S3>/Constant3'
   *  Product: '<S13>/Product'
   */
  theta = multirotor0_X.omega_CSTATE[1];
  q1 = multirotor0_X.omega_CSTATE[0];
  rtb_Product9_idx_0 = multirotor0_X.omega_CSTATE[2];
  for (i = 0; i < 3; i++) {
    /* Sum: '<S2>/Sum1' incorporates:
     *  Concatenate: '<S33>/Vector Concatenate'
     *  Constant: '<S3>/Constant2'
     *  Inport: '<Root>/force_disturbance'
     *  Merge: '<S39>/Merge'
     *  Product: '<S2>/Product1'
     *  Product: '<S37>/Product'
     *  Sum: '<S11>/Sum'
     *  Sum: '<S16>/Sum'
     *  Sum: '<S4>/Sum'
     *  Sum: '<S4>/Sum1'
     *  Sum: '<S4>/Sum3'
     */
    multirotor0_B.Sum1[i] = (((((rtb_VectorConcatenate[i + 3] * cphi +
      rtb_VectorConcatenate[i] * phi) + rtb_VectorConcatenate[i + 6] * ctheta) +
      rtb_Sum_a[i]) + multirotor0_B.Forceagainstdirectionofmotiondu[i]) +
      multirotor0_U.Force_disturb[i]) / 0.55 - (rtb_TrueairspeedBodyaxes[i] -
      rtb_TrueairspeedBodyaxes_m[i]);

    /* Product: '<S13>/Product' incorporates:
     *  Constant: '<S3>/Constant3'
     *  Integrator: '<S2>/omega'
     *  Product: '<S8>/Product'
     */
    rtb_TrueairspeedBodyaxes_b[i] = (multirotor0_ConstP.Constant3_Value[i + 3] *
      theta + multirotor0_ConstP.Constant3_Value[i] * q1) +
      multirotor0_ConstP.Constant3_Value[i + 6] * rtb_Product9_idx_0;
  }

  /* Sum: '<S12>/Sum' incorporates:
   *  Integrator: '<S2>/omega'
   *  Product: '<S14>/Product'
   *  Product: '<S14>/Product1'
   *  Product: '<S14>/Product2'
   *  Product: '<S15>/Product'
   *  Product: '<S15>/Product1'
   *  Product: '<S15>/Product2'
   */
  rtb_TrueairspeedBodyaxes[0] = multirotor0_X.omega_CSTATE[1] *
    rtb_TrueairspeedBodyaxes_b[2];
  rtb_TrueairspeedBodyaxes[1] = rtb_TrueairspeedBodyaxes_b[0] *
    multirotor0_X.omega_CSTATE[2];
  rtb_TrueairspeedBodyaxes[2] = multirotor0_X.omega_CSTATE[0] *
    rtb_TrueairspeedBodyaxes_b[1];
  rtb_TrueairspeedBodyaxes_m[0] = rtb_TrueairspeedBodyaxes_b[1] *
    multirotor0_X.omega_CSTATE[2];
  rtb_TrueairspeedBodyaxes_m[1] = multirotor0_X.omega_CSTATE[0] *
    rtb_TrueairspeedBodyaxes_b[2];
  rtb_TrueairspeedBodyaxes_m[2] = rtb_TrueairspeedBodyaxes_b[0] *
    multirotor0_X.omega_CSTATE[1];
  for (i = 0; i < 3; i++) {
    rtb_TrueairspeedBodyaxes_b[i] = rtb_TrueairspeedBodyaxes[i] -
      rtb_TrueairspeedBodyaxes_m[i];

    /* Sum: '<S38>/Sum of Elements1' incorporates:
     *  ForEachSliceAssignment generated from: '<S56>/Motor_moment'
     *  Sum: '<S16>/Sum'
     */
    rtb_Sum_a[i] = ((rtb_ImpAsg_InsertedFor_Motor_mo[i + 3] +
                     rtb_ImpAsg_InsertedFor_Motor_mo[i]) +
                    rtb_ImpAsg_InsertedFor_Motor_mo[i + 6]) +
      rtb_ImpAsg_InsertedFor_Motor_mo[i + 9];
  }

  /* End of Sum: '<S12>/Sum' */

  /* Product: '<S17>/Product' */
  q1 = 0.0;

  /* SignalConversion generated from: '<S8>/Q-Integrator' incorporates:
   *  Gain: '<S8>/1//2'
   *  Integrator: '<S2>/omega'
   *  Product: '<S20>/Product'
   *  Product: '<S20>/Product1'
   *  Product: '<S20>/Product2'
   *  Product: '<S21>/Product'
   *  Product: '<S21>/Product1'
   *  Product: '<S21>/Product2'
   *  Product: '<S8>/Product'
   *  Sum: '<S16>/Sum'
   *  Sum: '<S8>/Subtract'
   */
  multirotor0_B.TmpSignalConversionAtQIntegrato[1] = (rtb_Divide[0] *
    multirotor0_X.omega_CSTATE[0] - (multirotor0_X.omega_CSTATE[1] * rtb_Divide
    [3] - multirotor0_X.omega_CSTATE[2] * rtb_Divide[2])) * 0.5;
  multirotor0_B.TmpSignalConversionAtQIntegrato[2] = (rtb_Divide[0] *
    multirotor0_X.omega_CSTATE[1] - (rtb_Divide[1] * multirotor0_X.omega_CSTATE
    [2] - multirotor0_X.omega_CSTATE[0] * rtb_Divide[3])) * 0.5;
  multirotor0_B.TmpSignalConversionAtQIntegrato[3] = (rtb_Divide[0] *
    multirotor0_X.omega_CSTATE[2] - (multirotor0_X.omega_CSTATE[0] * rtb_Divide
    [2] - multirotor0_X.omega_CSTATE[1] * rtb_Divide[1])) * 0.5;

  /* Fcn: '<S9>/Fcn1' */
  rtb_VectorConcatenate_tmp_2 *= 2.0;

  /* Trigonometry: '<S9>/Trigonometric Function' */
  if (rtb_VectorConcatenate_tmp_2 > 1.0) {
    rtb_VectorConcatenate_tmp_2 = 1.0;
  } else if (rtb_VectorConcatenate_tmp_2 < -1.0) {
    rtb_VectorConcatenate_tmp_2 = -1.0;
  }

  /* Gain: '<S9>/Gain' incorporates:
   *  Outport: '<Root>/Euler'
   *  Trigonometry: '<S9>/Trigonometric Function'
   */
  multirotor0_Y.Euler[1] = -std::asin(rtb_VectorConcatenate_tmp_2);

  /* Trigonometry: '<S9>/Trigonometric Function1' incorporates:
   *  Fcn: '<S9>/Fcn'
   *  Outport: '<Root>/Euler'
   */
  multirotor0_Y.Euler[0] = rt_atan2d_snf(rtb_VectorConcatenate_tmp_1 * 2.0,
    rtb_VectorConcatenate_tmp_0);

  /* Trigonometry: '<S9>/Trigonometric Function2' incorporates:
   *  Fcn: '<S9>/Fcn2'
   *  Outport: '<Root>/Euler'
   */
  multirotor0_Y.Euler[2] = rt_atan2d_snf(rtb_VectorConcatenate_tmp * 2.0,
    rtb_VectorConcatenate_tmp_3);
  for (i = 0; i < 3; i++) {
    /* Sum: '<S7>/Sum1' incorporates:
     *  Inport: '<Root>/moment_disturbance'
     *  Product: '<S8>/Product'
     *  Sum: '<S16>/Sum'
     *  Sum: '<S4>/Sum2'
     */
    rtb_TrueairspeedBodyaxes[i] = (rtb_Sum_a[i] + multirotor0_U.Moment_disturb[i])
      - rtb_TrueairspeedBodyaxes_b[i];

    /* Product: '<S17>/Product' incorporates:
     *  Integrator: '<S2>/omega'
     */
    q1 += rtb_Divide[i + 1] * multirotor0_X.omega_CSTATE[i];

    /* Outport: '<Root>/X_i' incorporates:
     *  Integrator: '<S2>/X_i'
     */
    multirotor0_Y.X_i[i] = multirotor0_X.X_i_CSTATE[i];

    /* Outport: '<Root>/V_i' incorporates:
     *  Product: '<S5>/Product'
     */
    multirotor0_Y.V_i[i] = multirotor0_B.Product[i];

    /* Outport: '<Root>/V_b' incorporates:
     *  Integrator: '<S2>/V_b'
     */
    multirotor0_Y.V_b[i] = multirotor0_X.V_b_CSTATE[i];

    /* Outport: '<Root>/a_b' incorporates:
     *  Sum: '<S2>/Sum1'
     */
    multirotor0_Y.a_b[i] = multirotor0_B.Sum1[i];

    /* Outport: '<Root>/a_i' incorporates:
     *  Math: '<S6>/Math Function2'
     *  Product: '<S6>/Product'
     *  Sum: '<S2>/Sum1'
     */
    multirotor0_Y.a_i[i] = (Product_tmp[i + 3] * multirotor0_B.Sum1[1] +
      Product_tmp[i] * multirotor0_B.Sum1[0]) + Product_tmp[i + 6] *
      multirotor0_B.Sum1[2];
  }

  /* Product: '<S7>/Product' incorporates:
   *  Constant: '<S3>/Constant3'
   */
  rt_mldivide_U1d3x3_U2d_JBYZyA3A(multirotor0_ConstP.Constant3_Value,
    rtb_TrueairspeedBodyaxes, multirotor0_B.Product_l);

  /* SignalConversion generated from: '<S8>/Q-Integrator' incorporates:
   *  Gain: '<S8>/-1//2'
   *  Product: '<S17>/Product'
   */
  multirotor0_B.TmpSignalConversionAtQIntegrato[0] = -0.5 * q1;

  /* End of Outputs for SubSystem: '<Root>/multirotor' */

  /* Outport: '<Root>/DCM_ib' incorporates:
   *  Concatenate: '<S33>/Vector Concatenate'
   */
  std::memcpy(&multirotor0_Y.DCM_ib[0], &rtb_VectorConcatenate[0], 9U * sizeof
              (real_T));

  /* Outport: '<Root>/Quat q' incorporates:
   *  Product: '<S19>/Divide'
   */
  multirotor0_Y.Quatq[0] = rtb_Divide[0];
  multirotor0_Y.Quatq[1] = rtb_Divide[1];
  multirotor0_Y.Quatq[2] = rtb_Divide[2];
  multirotor0_Y.Quatq[3] = rtb_Divide[3];

  /* Outputs for Atomic SubSystem: '<Root>/multirotor' */
  /* Outport: '<Root>/omega' incorporates:
   *  Integrator: '<S2>/omega'
   */
  multirotor0_Y.omega[0] = multirotor0_X.omega_CSTATE[0];

  /* End of Outputs for SubSystem: '<Root>/multirotor' */

  /* Outport: '<Root>/omega_dot' incorporates:
   *  Product: '<S7>/Product'
   */
  multirotor0_Y.omega_dot[0] = multirotor0_B.Product_l[0];

  /* Outputs for Atomic SubSystem: '<Root>/multirotor' */
  /* Outport: '<Root>/omega' incorporates:
   *  Integrator: '<S2>/omega'
   */
  multirotor0_Y.omega[1] = multirotor0_X.omega_CSTATE[1];

  /* End of Outputs for SubSystem: '<Root>/multirotor' */

  /* Outport: '<Root>/omega_dot' incorporates:
   *  Product: '<S7>/Product'
   */
  multirotor0_Y.omega_dot[1] = multirotor0_B.Product_l[1];

  /* Outputs for Atomic SubSystem: '<Root>/multirotor' */
  /* Outport: '<Root>/omega' incorporates:
   *  Integrator: '<S2>/omega'
   */
  multirotor0_Y.omega[2] = multirotor0_X.omega_CSTATE[2];

  /* End of Outputs for SubSystem: '<Root>/multirotor' */

  /* Outport: '<Root>/omega_dot' incorporates:
   *  Product: '<S7>/Product'
   */
  multirotor0_Y.omega_dot[2] = multirotor0_B.Product_l[2];

  /* Outport: '<Root>/motor_RPM' incorporates:
   *  ForEachSliceAssignment generated from: '<S56>/RPM_motor'
   */
  multirotor0_Y.motor_RPM[0] = rtb_ImpAsg_InsertedFor_RPM_moto[0];
  multirotor0_Y.motor_RPM[1] = rtb_ImpAsg_InsertedFor_RPM_moto[1];
  multirotor0_Y.motor_RPM[2] = rtb_ImpAsg_InsertedFor_RPM_moto[2];
  multirotor0_Y.motor_RPM[3] = rtb_ImpAsg_InsertedFor_RPM_moto[3];
  if (rtmIsMajorTimeStep((&multirotor0_M))) {
    /* Update for Atomic SubSystem: '<Root>/multirotor' */
    /* Update for Integrator: '<S8>/Q-Integrator' */
    multirotor0_DW.QIntegrator_IWORK = 0;

    /* End of Update for SubSystem: '<Root>/multirotor' */
  }                                    /* end MajorTimeStep */

  if (rtmIsMajorTimeStep((&multirotor0_M))) {
    rt_ertODEUpdateContinuousStates(&(&multirotor0_M)->solverInfo);

    /* Update absolute time */
    /* The "clockTick0" counts the number of times the code of this task has
     * been executed. The absolute time is the multiplication of "clockTick0"
     * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
     * overflow during the application lifespan selected.
     */
    ++(&multirotor0_M)->Timing.clockTick0;
    (&multirotor0_M)->Timing.t[0] = rtsiGetSolverStopTime(&(&multirotor0_M)
      ->solverInfo);

    /* Update absolute time */
    /* The "clockTick1" counts the number of times the code of this task has
     * been executed. The resolution of this integer timer is 0.001, which is the step size
     * of the task. Size of "clockTick1" ensures timer will not overflow during the
     * application lifespan selected.
     */
    (&multirotor0_M)->Timing.clockTick1++;
  }                                    /* end MajorTimeStep */
}

/* Derivatives for root system: '<Root>' */
void multirotor0::multirotor0_derivatives()
{
  /* local scratch DWork variables */
  int32_T ForEach_itr;
  XDot_multirotor0_T *_rtXdot;
  _rtXdot = ((XDot_multirotor0_T *) (&multirotor0_M)->derivs);

  /* Derivatives for Atomic SubSystem: '<Root>/multirotor' */
  /* Derivatives for Integrator: '<S8>/Q-Integrator' incorporates:
   *  SignalConversion generated from: '<S8>/Q-Integrator'
   */
  _rtXdot->QIntegrator_CSTATE[0] =
    multirotor0_B.TmpSignalConversionAtQIntegrato[0];
  _rtXdot->QIntegrator_CSTATE[1] =
    multirotor0_B.TmpSignalConversionAtQIntegrato[1];
  _rtXdot->QIntegrator_CSTATE[2] =
    multirotor0_B.TmpSignalConversionAtQIntegrato[2];
  _rtXdot->QIntegrator_CSTATE[3] =
    multirotor0_B.TmpSignalConversionAtQIntegrato[3];

  /* Derivatives for Integrator: '<S2>/V_b' incorporates:
   *  Sum: '<S2>/Sum1'
   */
  _rtXdot->V_b_CSTATE[0] = multirotor0_B.Sum1[0];

  /* Derivatives for Integrator: '<S2>/omega' incorporates:
   *  Product: '<S7>/Product'
   */
  _rtXdot->omega_CSTATE[0] = multirotor0_B.Product_l[0];

  /* Derivatives for Integrator: '<S2>/V_b' incorporates:
   *  Sum: '<S2>/Sum1'
   */
  _rtXdot->V_b_CSTATE[1] = multirotor0_B.Sum1[1];

  /* Derivatives for Integrator: '<S2>/omega' incorporates:
   *  Product: '<S7>/Product'
   */
  _rtXdot->omega_CSTATE[1] = multirotor0_B.Product_l[1];

  /* Derivatives for Integrator: '<S2>/V_b' incorporates:
   *  Sum: '<S2>/Sum1'
   */
  _rtXdot->V_b_CSTATE[2] = multirotor0_B.Sum1[2];

  /* Derivatives for Integrator: '<S2>/omega' incorporates:
   *  Product: '<S7>/Product'
   */
  _rtXdot->omega_CSTATE[2] = multirotor0_B.Product_l[2];

  /* Derivatives for Iterator SubSystem: '<S38>/For Each Subsystem' */
  for (ForEach_itr = 0; ForEach_itr < 4; ForEach_itr++) {
    /* Derivatives for Integrator: '<S62>/Integrator' */
    _rtXdot->CoreSubsys[ForEach_itr].Integrator_CSTATE =
      multirotor0_B.CoreSubsys[ForEach_itr].Switch;

    /* Derivatives for Integrator: '<S63>/Integrator' */
    _rtXdot->CoreSubsys[ForEach_itr].Integrator_CSTATE_o =
      multirotor0_B.CoreSubsys[ForEach_itr].Switch_a;
  }

  /* End of Derivatives for SubSystem: '<S38>/For Each Subsystem' */

  /* Derivatives for Integrator: '<S2>/X_i' incorporates:
   *  Product: '<S5>/Product'
   */
  _rtXdot->X_i_CSTATE[0] = multirotor0_B.Product[0];
  _rtXdot->X_i_CSTATE[1] = multirotor0_B.Product[1];
  _rtXdot->X_i_CSTATE[2] = multirotor0_B.Product[2];

  /* End of Derivatives for SubSystem: '<Root>/multirotor' */
}

/* Model step function for TID2 */
void multirotor0::step2()              /* Sample time: [0.002s, 0.0s] */
{
  /* Update for Atomic SubSystem: '<Root>/multirotor' */
  /* Update for RateTransition: '<S1>/Rate Transition1' incorporates:
   *  Inport: '<Root>/RPM commands'
   */
  multirotor0_DW.RateTransition1_Buffer0[0] = multirotor0_U.RPMcommands[0];
  multirotor0_DW.RateTransition1_Buffer0[1] = multirotor0_U.RPMcommands[1];
  multirotor0_DW.RateTransition1_Buffer0[2] = multirotor0_U.RPMcommands[2];
  multirotor0_DW.RateTransition1_Buffer0[3] = multirotor0_U.RPMcommands[3];

  /* End of Update for SubSystem: '<Root>/multirotor' */
}

/* Model initialize function */
void multirotor0::initialize()
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* Set task counter limit used by the static main program */
  ((&multirotor0_M))->Timing.TaskCounters.cLimit[0] = 1;
  ((&multirotor0_M))->Timing.TaskCounters.cLimit[1] = 1;
  ((&multirotor0_M))->Timing.TaskCounters.cLimit[2] = 2;

  {
    /* Setup solver object */
    rtsiSetSimTimeStepPtr(&(&multirotor0_M)->solverInfo, &(&multirotor0_M)
                          ->Timing.simTimeStep);
    rtsiSetTPtr(&(&multirotor0_M)->solverInfo, &rtmGetTPtr((&multirotor0_M)));
    rtsiSetStepSizePtr(&(&multirotor0_M)->solverInfo, &(&multirotor0_M)
                       ->Timing.stepSize0);
    rtsiSetdXPtr(&(&multirotor0_M)->solverInfo, &(&multirotor0_M)->derivs);
    rtsiSetContStatesPtr(&(&multirotor0_M)->solverInfo, (real_T **)
                         &(&multirotor0_M)->contStates);
    rtsiSetNumContStatesPtr(&(&multirotor0_M)->solverInfo, &(&multirotor0_M)
      ->Sizes.numContStates);
    rtsiSetNumPeriodicContStatesPtr(&(&multirotor0_M)->solverInfo,
      &(&multirotor0_M)->Sizes.numPeriodicContStates);
    rtsiSetPeriodicContStateIndicesPtr(&(&multirotor0_M)->solverInfo,
      &(&multirotor0_M)->periodicContStateIndices);
    rtsiSetPeriodicContStateRangesPtr(&(&multirotor0_M)->solverInfo,
      &(&multirotor0_M)->periodicContStateRanges);
    rtsiSetErrorStatusPtr(&(&multirotor0_M)->solverInfo, (&rtmGetErrorStatus
      ((&multirotor0_M))));
    rtsiSetRTModelPtr(&(&multirotor0_M)->solverInfo, (&multirotor0_M));
  }

  rtsiSetSimTimeStep(&(&multirotor0_M)->solverInfo, MAJOR_TIME_STEP);
  (&multirotor0_M)->intgData.y = (&multirotor0_M)->odeY;
  (&multirotor0_M)->intgData.f[0] = (&multirotor0_M)->odeF[0];
  (&multirotor0_M)->intgData.f[1] = (&multirotor0_M)->odeF[1];
  (&multirotor0_M)->intgData.f[2] = (&multirotor0_M)->odeF[2];
  (&multirotor0_M)->contStates = ((X_multirotor0_T *) &multirotor0_X);
  rtsiSetSolverData(&(&multirotor0_M)->solverInfo, static_cast<void *>
                    (&(&multirotor0_M)->intgData));
  rtsiSetIsMinorTimeStepWithModeChange(&(&multirotor0_M)->solverInfo, false);
  rtsiSetSolverName(&(&multirotor0_M)->solverInfo,"ode3");
  rtmSetTPtr((&multirotor0_M), &(&multirotor0_M)->Timing.tArray[0]);
  (&multirotor0_M)->Timing.stepSize0 = 0.001;
  rtmSetFirstInitCond((&multirotor0_M), 1);

  {
    /* local scratch DWork variables */
    int32_T ForEach_itr;

    /* Start for Atomic SubSystem: '<Root>/multirotor' */
    /* Start for RateTransition: '<S1>/Rate Transition1' */
    multirotor0_B.RateTransition1[0] = 3104.5025852;
    multirotor0_B.RateTransition1[1] = 3104.5025852;
    multirotor0_B.RateTransition1[2] = 3104.5025852;
    multirotor0_B.RateTransition1[3] = 3104.5025852;

    /* Start for Iterator SubSystem: '<S38>/For Each Subsystem' */
    for (ForEach_itr = 0; ForEach_itr < 4; ForEach_itr++) {
      /* Start for If: '<S89>/If' */
      multirotor0_DW.CoreSubsys[ForEach_itr].If_ActiveSubsystem = -1;

      /* Start for If: '<S87>/If' */
      multirotor0_DW.CoreSubsys[ForEach_itr].If_ActiveSubsystem_l = -1;

      /* Start for If: '<S75>/If' */
      multirotor0_DW.CoreSubsys[ForEach_itr].If_ActiveSubsystem_e = -1;
    }

    /* End of Start for SubSystem: '<S38>/For Each Subsystem' */

    /* Start for If: '<S39>/If' */
    multirotor0_DW.If_ActiveSubsystem = -1;

    /* End of Start for SubSystem: '<Root>/multirotor' */
  }

  {
    /* local scratch DWork variables */
    int32_T ForEach_itr;

    /* SystemInitialize for Atomic SubSystem: '<Root>/multirotor' */
    /* InitializeConditions for Integrator: '<S8>/Q-Integrator' */
    if (rtmIsFirstInitCond((&multirotor0_M))) {
      multirotor0_X.QIntegrator_CSTATE[0] = 0.0;
      multirotor0_X.QIntegrator_CSTATE[1] = 0.0;
      multirotor0_X.QIntegrator_CSTATE[2] = 0.0;
      multirotor0_X.QIntegrator_CSTATE[3] = 0.0;
    }

    multirotor0_DW.QIntegrator_IWORK = 1;

    /* End of InitializeConditions for Integrator: '<S8>/Q-Integrator' */

    /* InitializeConditions for Integrator: '<S2>/V_b' */
    multirotor0_X.V_b_CSTATE[0] = 0.0;
    multirotor0_X.V_b_CSTATE[1] = 0.0;
    multirotor0_X.V_b_CSTATE[2] = 0.0;

    /* InitializeConditions for RateTransition: '<S1>/Rate Transition1' */
    multirotor0_DW.RateTransition1_Buffer0[0] = 3104.5025852;
    multirotor0_DW.RateTransition1_Buffer0[1] = 3104.5025852;
    multirotor0_DW.RateTransition1_Buffer0[2] = 3104.5025852;
    multirotor0_DW.RateTransition1_Buffer0[3] = 3104.5025852;

    /* InitializeConditions for Integrator: '<S2>/omega' */
    multirotor0_X.omega_CSTATE[0] = 0.0;

    /* InitializeConditions for Integrator: '<S2>/X_i' */
    multirotor0_X.X_i_CSTATE[0] = 0.0;

    /* SystemInitialize for IfAction SubSystem: '<S39>/Zero airspeed' */
    /* SystemInitialize for Merge: '<S39>/Merge' incorporates:
     *  Outport: '<S42>/Drag force'
     */
    multirotor0_B.Forceagainstdirectionofmotiondu[0] = 0.0;

    /* End of SystemInitialize for SubSystem: '<S39>/Zero airspeed' */

    /* InitializeConditions for Integrator: '<S2>/omega' */
    multirotor0_X.omega_CSTATE[1] = 0.0;

    /* InitializeConditions for Integrator: '<S2>/X_i' */
    multirotor0_X.X_i_CSTATE[1] = 0.0;

    /* SystemInitialize for IfAction SubSystem: '<S39>/Zero airspeed' */
    /* SystemInitialize for Merge: '<S39>/Merge' incorporates:
     *  Outport: '<S42>/Drag force'
     */
    multirotor0_B.Forceagainstdirectionofmotiondu[1] = 0.0;

    /* End of SystemInitialize for SubSystem: '<S39>/Zero airspeed' */

    /* InitializeConditions for Integrator: '<S2>/omega' */
    multirotor0_X.omega_CSTATE[2] = 0.0;

    /* InitializeConditions for Integrator: '<S2>/X_i' */
    multirotor0_X.X_i_CSTATE[2] = 0.0;

    /* SystemInitialize for IfAction SubSystem: '<S39>/Zero airspeed' */
    /* SystemInitialize for Merge: '<S39>/Merge' incorporates:
     *  Outport: '<S42>/Drag force'
     */
    multirotor0_B.Forceagainstdirectionofmotiondu[2] = -1.0;

    /* End of SystemInitialize for SubSystem: '<S39>/Zero airspeed' */

    /* SystemInitialize for Iterator SubSystem: '<S38>/For Each Subsystem' */
    for (ForEach_itr = 0; ForEach_itr < 4; ForEach_itr++) {
      /* InitializeConditions for Integrator: '<S62>/Integrator' */
      multirotor0_X.CoreSubsys[ForEach_itr].Integrator_CSTATE = 3104.5025852;

      /* InitializeConditions for Integrator: '<S63>/Integrator' */
      multirotor0_X.CoreSubsys[ForEach_itr].Integrator_CSTATE_o = 3104.5025852;

      /* SystemInitialize for IfAction SubSystem: '<S75>/Zero airspeed in rotor plane' */
      /* SystemInitialize for Merge: '<S75>/Merge' incorporates:
       *  Outport: '<S82>/Thrust direction (Body)'
       */
      multirotor0_B.CoreSubsys[ForEach_itr].NewtiltedthrustdirectionBodyaxe[0] =
        0.0;
      multirotor0_B.CoreSubsys[ForEach_itr].NewtiltedthrustdirectionBodyaxe[1] =
        0.0;
      multirotor0_B.CoreSubsys[ForEach_itr].NewtiltedthrustdirectionBodyaxe[2] =
        -1.0;

      /* End of SystemInitialize for SubSystem: '<S75>/Zero airspeed in rotor plane' */
    }

    /* End of SystemInitialize for SubSystem: '<S38>/For Each Subsystem' */
    /* End of SystemInitialize for SubSystem: '<Root>/multirotor' */

    /* set "at time zero" to false */
    if (rtmIsFirstInitCond((&multirotor0_M))) {
      rtmSetFirstInitCond((&multirotor0_M), 0);
    }
  }
}

/* Model terminate function */
void multirotor0::terminate()
{
  /* (no terminate code required) */
}

/* Constructor */
multirotor0::multirotor0() :
  multirotor0_U(),
  multirotor0_Y(),
  multirotor0_B(),
  multirotor0_DW(),
  multirotor0_X(),
  multirotor0_M()
{
  /* Currently there is no constructor body generated.*/
}

/* Destructor */
/* Currently there is no destructor body generated.*/
multirotor0::~multirotor0() = default;

/* Real-Time Model get method */
RT_MODEL_multirotor0_T * multirotor0::getRTM()
{
  return (&multirotor0_M);
}
